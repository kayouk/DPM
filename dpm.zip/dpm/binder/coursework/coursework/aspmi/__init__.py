
def two():
    print("This is aspmi")

def three():
    print("This is aspmi three")