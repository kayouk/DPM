---
name: 🚀 Feature request or improvement
about: Suggest an idea for this project.
labels: 'Type: Enhancement'
assignees: IlyaKisil
title: ''
---

<!-- Provide a general summary of the issue in the Title above -->


<!-- A clear and concise description of what you want to happen. -->
## Description


<!-- Add any other context or screenshots about the feature request here. -->
## Additional context
